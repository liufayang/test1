create
    definer = root@localhost function func_selfhelp_condi(a_arch_type varchar(100), a_query_type varchar(1),
                                                          a_card_id varchar(20), a_name varchar(50), a_sex varchar(10),
                                                          a_birth varchar(20), a_condi_type varchar(10),
                                                          a_condi_value varchar(10)) returns varchar(500)
BEGIN
	#a_arch_type:门类ID
	#a_query_type:查询类型（1、身份证号；2、姓名+性别+出生日期；3、姓名+性别+出生日期+补充条件）
	#a_card_id:身份证号
	#a_name:姓名
	#a_sex:性别
	#a_birth:出生日期
	#a_condi_type:补充条件类型（1、配偶姓名；2、当前人是父母还是子女,0:其它,1:父母2:子女）
	#a_condi_value:补充条件值（1、配偶姓名；2、父母or子女）
	DECLARE str_value varchar(500);
	
	case a_arch_type 
		when '9481818661f9f9a40161fa3d4d720403' then#门类嵌套--婚姻档案
				case a_query_type #查询类型嵌套
				 	when '1' then 
							If a_sex = '1' then
									set str_value = concat('MAN_ID_ENFICATION&MAN_ID_ENFICATION=',a_card_id);#拼接对应性别的身份证号字段
							ELSE
									set str_value = concat('WOMAN_ID_ENTIFICATION&WOMAN_ID_ENTIFICATION=',a_card_id);#拼接对应性别的身份证号字段
							end if;
					when '2' then 
							If a_sex = '1' then
									set str_value = concat('MAN,&MAN=',a_name);#拼接对应性别的姓名+出生日期字段
							ELSE
									set str_value = concat('WOMAN&WOMAN=',a_name);#拼接对应性别的姓名+出生日期字段
							end if;
					when '3' then 
							If a_sex = '1' then
									set str_value = concat('MAN,WOMAN&MAN=',a_name,'&WOMAN=',a_condi_value);#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
							ELSE
									set str_value = concat('MAN,WOMAN&MAN=',a_condi_value,'&WOMAN=',a_name);#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
							end if;
					end case;
		when '9481818661f9f9a40161fa3b2d0102b7' then#门类嵌套--独生子女档案
			case a_query_type #查询类型嵌套
					when '1' then 
							#If a_sex = '1' then
									set str_value = concat('CERTIFICATION_CODE&CERTIFICATION_CODE=',a_card_id);#拼接对应性别的身份证号字段
							#ELSE
									#set str_value = concat('CERTIFICATION_CODE,SEX&CERTIFICATION_CODE=',a_card_id,'&SEX=','0');#拼接对应性别的身份证号字段
							#end if;
					when '2' then 
							#If a_sex = '1' then
									set str_value = concat('SEX,DATE_OF_BIRTH&SEX=','1','&DATE_OF_BIRTH=',a_birth);#拼接对应性别的姓名+出生日期字段
							#ELSE
									#set str_value = '1';#拼接对应性别的姓名+出生日期字段
							#end if;
					when '3' then 
							If a_sex = '1' then
									IF a_condi_type = '1' then#父母
										set str_value = concat('FATHER_NAME,DATE_OF_BIRTH&FATHER_NAME=',a_name,'&DATE_OF_BIRTH=',a_birth);#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
									ELSE
										set str_value = concat('CHILD_NAME,DATE_OF_BIRTH&CHILD_NAME=',a_name,'&DATE_OF_BIRTH=',a_birth);
									end if;
#set str_value = concat('SEX,DATE_OF_BIRTH&SEX=','1','&DATE_OF_BIRTH=',a_birth);#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
							ELSE
									IF a_condi_type = '1' then#父母
										set str_value = concat('MOTHER_NAME,DATE_OF_BIRTH&MOTHER_NAME=',a_name,'&DATE_OF_BIRTH=',a_birth);#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
									ELSE
										set str_value = concat('CHILD_NAME,DATE_OF_BIRTH&CHILD_NAME=',a_name,'&DATE_OF_BIRTH=',a_birth);
									end if;
									#拼接对应性别的姓名+出生日期字段再加上辅助查询条件拼接
							end if;
					end case;
		else
				set str_value = '2';
	end case;

	RETURN str_value;
END;

